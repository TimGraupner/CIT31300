<?php

class LoginController extends Controller{

   //public function add($num1 = 0,$num2 = 0,$num3 = 0){
		//$sum = $num1+$num2+$num3;
	   //$this->set('numbers',$sum);
   //}

   public function do_login() {
		 session_start();
		 if (password_verify('password', $hash)) {
		 verify
		 $_SESSION["userID"] = t

	   // handles login
   }

}
